import view.*;

public class App {
    
    static GUI g = new GUI();

    public static void main(String[] args) throws Exception {
        g.setVisible(true);
    }

}
